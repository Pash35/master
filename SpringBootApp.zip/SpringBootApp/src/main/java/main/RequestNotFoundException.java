package main;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class RequestNotFoundException extends Exception{
    private String message;

}
