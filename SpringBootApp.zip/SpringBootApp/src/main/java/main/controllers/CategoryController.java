package main.controllers;

import main.RequestNotFoundException;
import main.dto.CategoryDto;
import main.services.CategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping("/{id}")
    public CategoryDto getNewsByID (@PathVariable Long id) throws RequestNotFoundException {
        try {
            return categoryService.getById(id);
        }
        catch (RequestNotFoundException e) {
            System.out.println(e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }

    @GetMapping
    public Collection<CategoryDto> getAllNews () {
        return categoryService.getAll();
    }

    @PostMapping
    public ResponseEntity<?> createNews (@RequestBody CategoryDto categoryDto) {
        return new ResponseEntity<>(categoryService.create(categoryDto), HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<?> updateNews (@RequestBody CategoryDto categoryDto) {
        return new ResponseEntity<>(categoryService.update(categoryDto), HttpStatus.OK);
    }
    @DeleteMapping("/{id}")
    public void deleteNews (@PathVariable Long id) {
        try {
            categoryService.deleteById(id);
        }
        catch (RequestNotFoundException e) {
            System.out.println(e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }

    }
}
