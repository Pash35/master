package main.controllers;

import main.RequestNotFoundException;
import main.dto.NewsDto;
import main.services.NewsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;

@RestController
@RequestMapping("/api/news")
public class NewsController {
    private final NewsService newsService;


    public NewsController(NewsService newsService) {
        this.newsService = newsService;
    }

    @GetMapping("/{id}")
    public NewsDto getNewsByID (@PathVariable Long id) throws RequestNotFoundException {
        try {
            return newsService.getById(id);
        }
        catch (RequestNotFoundException e) {
            System.out.println(e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }

    @GetMapping("/category/{id}")
    public Collection<NewsDto> getNewsOneCategoryByID (@PathVariable Long id) throws RequestNotFoundException {
        try {
            return newsService.getByIdCategory(id);
        }
        catch (RequestNotFoundException e) {
            System.out.println(e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }

    @GetMapping
    public Collection<NewsDto> getAllNews () {
        return newsService.getAll();
    }

    @PostMapping
    public ResponseEntity<?>  createNews (@RequestBody NewsDto newsDto) {
        return new ResponseEntity<>(newsService.create(newsDto), HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<?> updateNews (@RequestBody NewsDto newsDto) {
        return new ResponseEntity<>(newsService.update(newsDto), HttpStatus.OK);
    }
    @DeleteMapping("/{id}")
    public void deleteNews (@PathVariable Long id) {
        try {
            newsService.deleteById(id);
        }
        catch (RequestNotFoundException e) {
            System.out.println(e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }

    }
}
