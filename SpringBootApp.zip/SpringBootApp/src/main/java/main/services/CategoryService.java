package main.services;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import main.RequestNotFoundException;
import main.dto.CategoryDto;
import main.entity.Category;
import main.repositories.CategoryRepository;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Slf4j
@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository repository;
    public CategoryDto getById (Long id) throws RequestNotFoundException {
        log.info("get by Id: " + id);
        Category category = repository.findById(id)
                .orElseThrow(() -> new RequestNotFoundException("Категория с ID " + id + " не найдена."));
        return mapToDto(category);
    }

    public Collection<CategoryDto> getAll () {
        log.info("get all");
        return repository.findAll().stream()
                .map(CategoryService::mapToDto)
                .toList();
    }

    public CategoryDto create (CategoryDto categoryDto) {
        log.info("create");
        Category category = mapToEntity(categoryDto);
        repository.save(category);
        return mapToDto(repository.getReferenceById(category.getId()));
    }

    public CategoryDto update (CategoryDto categoryDto) {
        log.info("update");
        Category category = mapToEntity(categoryDto);
        repository.save(category);
        return categoryDto;
    }

    public void deleteById (Long id) throws RequestNotFoundException {
        log.info("delete ID: " + id);
        if (!repository.findById(id).isEmpty()) {
            repository.deleteById(id);
        } else throw new RequestNotFoundException("Категория с ID " + id + " не найдена.");
    }

    public static CategoryDto mapToDto(Category category) {
        CategoryDto categoryDto = new CategoryDto();
        categoryDto.setId(category.getId());
        categoryDto.setTitle(category.getTitle());
        return categoryDto;
    }

    public static Category mapToEntity(CategoryDto categoryDto) {
        Category category = new Category();
        category.setId(categoryDto.getId());
        category.setTitle(categoryDto.getTitle());
        return category;
    }
}
