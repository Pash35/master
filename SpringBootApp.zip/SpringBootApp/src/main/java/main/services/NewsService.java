package main.services;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import main.RequestNotFoundException;
import main.dto.NewsDto;
import main.entity.Category;
import main.entity.News;
import main.repositories.CategoryRepository;
import main.repositories.NewsRepository;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Collection;

@Slf4j
@Service
@RequiredArgsConstructor
public class NewsService {


    private final NewsRepository newsRepository;
    private final CategoryRepository categoryRepository;
    public NewsDto getById (Long id) throws RequestNotFoundException {
        log.info("get by Id: " + id);
        News news = newsRepository.findById(id)
                .orElseThrow(() -> new RequestNotFoundException("Новость с ID " + id + " не найдена."));
        return mapToDto(news);
    }

    public Collection<NewsDto> getByIdCategory (Long id) throws RequestNotFoundException {
        log.info("get by Id category: " + id);
        return newsRepository.findAllByCategory(id).stream()
                .map(NewsService::mapToDto)
                .toList();
    }

    public Collection<NewsDto> getAll () {
        log.info("get all");
        return newsRepository.findAll().stream()
                .map(NewsService::mapToDto)
                .toList();
    }

    public NewsDto create (NewsDto newsDto) {
        log.info("create");
        News news = mapToEntity(newsDto);
        Category category = categoryRepository.findByTitle(newsDto.getCategory());
        news.setCategory(category);
        newsRepository.save(news);
        return mapToDto(newsRepository.getReferenceById(news.getId()));
    }

    public NewsDto update (NewsDto newsDto) {
        log.info("update");
        News news = mapToEntity(newsDto);
        Category category = categoryRepository.findByTitle(newsDto.getCategory());
        news.setCategory(category);
        newsRepository.save(news);
        return mapToDto(newsRepository.findById(news.getId()).orElseThrow());
    }

    public void deleteById (Long id) throws RequestNotFoundException {
        log.info("delete ID: " + id);
        newsRepository.deleteById(id);
    }

    public static NewsDto mapToDto(News news) {
        NewsDto newsDto = new NewsDto();
        newsDto.setId(news.getId());
        newsDto.setTitle(news.getTitle());
        newsDto.setText(news.getText());
        newsDto.setDate(news.getDate());
        newsDto.setCategory(news.getCategory().getTitle());
        return newsDto;
    }

    public static News mapToEntity(NewsDto newsDto) {
        News news = new News();
        news.setId(newsDto.getId());
        news.setTitle(newsDto.getTitle());
        news.setText(newsDto.getText());
        news.setDate(Instant.now());
        return news;
    }
}
