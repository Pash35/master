package searchengine.model;

public enum Status {
    INDEXING,
    INDEXED,
    FAILED
}
